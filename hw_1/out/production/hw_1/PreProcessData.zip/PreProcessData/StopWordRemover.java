package PreProcessData;

import Classes.Path;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StopWordRemover {
    //you can add essential private methods or variables.
    private HashSet<String> stopword;
    private BufferedReader br;
    private FileInputStream fis;

    public StopWordRemover() throws IOException {
        // load and store the stop words from the fileinputstream with appropriate data structure
        // that you believe is suitable for matching stop words.
        // address of stopword.txt should be Path.StopwordDir
        stopword = new HashSet<>();
        String word, line;
        try {
            fis = new FileInputStream(Path.StopwordDir);
            br = new BufferedReader(new InputStreamReader(fis));
            System.out.println("********stopword File opened********");
            line = br.readLine();
            while (line!=null) {
                stopword.add(line);
                line = br.readLine();
            }
        }catch (IOException e) {
            Logger.getLogger(TrectextCollection.class.getName()).log(Level.SEVERE, null, e);
        }finally {
            br.close();
            fis.close();
        }
    }

    // YOU MUST IMPLEMENT THIS METHOD
    public boolean isStopword(char[] word) {
        // return true if the input word is a stopword, or false if not
        if(stopword.contains(String.valueOf(word))) return true;
        return false;
    }
}
