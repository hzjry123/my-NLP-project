package PreProcessData;

import Classes.Stemmer;

/**
 * This is for INFSCI 2140 in 2018
 */
public class WordNormalizer {
    //you can add essential private methods or variables

    public static void main(String[] main) {
        WordNormalizer wn = new WordNormalizer();
        char[] chars = {'A', 'B'};
        wn.lowercase(chars);
        for (char ou : chars
                ) {
            System.out.println(ou);
        }
    }

    // YOU MUST IMPLEMENT THIS METHOD
    public char[] lowercase(char[] chars) {
        //transform the uppercase characters in the word to lowercase
        for (int i = 0; i < chars.length; i++)
            if (chars[i] >= 'A' && chars[i] <= 'Z') {//if it is a uppercase
                chars[i] = (char) (chars[i] - 'A' + 'a');//change it to a lowercase
            }
        return chars;
    }

    public String stem(char[] chars) {
        //use the stemmer in Classes package to do the stemming on input word, and return the stemmed word

        Stemmer s = new Stemmer();
        s.add(chars, chars.length);
        s.stem();

        return String.valueOf(s);
    }
}
