package PreProcessData;

import java.io.IOException;
import java.util.Map;

/**
 * This is for INFSCI 2140 in 2018
 * 
 * TextTokenizer can split a sequence of text into individual word tokens.
 */
//TODO:
public class WordTokenizer {
	//you can add essential private methods or variables
	private String[] words;
	private int pos = 0;//words position
	// YOU MUST IMPLEMENT THIS METHOD
	public WordTokenizer( char[] texts ) {
		// this constructor will tokenize the input texts (usually it is a char array for a whole document)
		String token = new String(texts);
		token = token.replaceAll("[^a-zA-Z'\\pZ]", " ");//[]P, 标点符合，N：number，S：数学符号
		words = token.split("[\\s]+"); // split word
	}
	
	// YOU MUST IMPLEMENT THIS METHOD
	public char[] nextWord() {
		// read and return the next word of the document
		// or return null if it is the end of the document
		if(pos < words.length) {
				return words[pos++].toCharArray();
			}
		else return null;
	}
	public static void main(String[] main) throws IOException {
		String s = "Mr. jin ruo + w3c \n 456 \"adasda\" yu's 'is' student-hhahaha.";
		WordTokenizer wt = new WordTokenizer(s.toCharArray());
		System.out.println(String.valueOf(wt.nextWord()));
		System.out.println(String.valueOf(wt.nextWord()));
		System.out.println(String.valueOf(wt.nextWord()));
		System.out.println(String.valueOf(wt.nextWord()));
		System.out.println(String.valueOf(wt.nextWord()));
		System.out.println(String.valueOf(wt.nextWord()));
//		System.out.println(String.valueOf(wt.nextWord()));
//		System.out.println(String.valueOf(wt.nextWord()));
//		System.out.println(String.valueOf(wt.nextWord()));
//		System.out.println(String.valueOf(wt.nextWord()));
//		System.out.println(String.valueOf(wt.nextWord()));
//		System.out.println(String.valueOf(wt.nextWord()));

		if(wt.nextWord() == null) {
			System.out.println("yes");
		}
	}
}
