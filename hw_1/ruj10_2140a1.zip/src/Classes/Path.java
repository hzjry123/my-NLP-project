package Classes;

public class Path {
	public static String StopwordDir="data//stopword.txt";//address of stopwords.txt
	public static String ResultHM1="data//results.";//
	
	
	public static String DataWebDir="data//docset.trecweb";//address of docset.trectext
	public static String DataTextDir="data//docset.trectext";//address of docset.trectext

}
